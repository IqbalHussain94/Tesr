﻿b. Login

1. Verify that a registered user can log in with valid credentials.
1. Verify that an unregistered user cannot log in.
1. Verify that incorrect passwords prevent login.
1. Verify that the 'Forgot Password' functionality works correctly.
1. Verify that user can login with OTP

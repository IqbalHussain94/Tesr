﻿1. Verify that a user can register with valid details.
1. Verify that duplicate email addresses cannot be registered.
1. Verify the password strength requirements.
1. Verify the email confirmation link works correctly.
